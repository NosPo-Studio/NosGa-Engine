

--[[This is a little example mod.
	This file is to store infos about the mod but thats currently not used.
]]