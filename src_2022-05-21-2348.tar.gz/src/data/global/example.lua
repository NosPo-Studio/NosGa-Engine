local value = "example"
value = value .. " value"
return value