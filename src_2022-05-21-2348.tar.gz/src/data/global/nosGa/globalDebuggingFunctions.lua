local global = ...

function gs()
	return global.getState()
end