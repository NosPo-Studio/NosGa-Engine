local global = ...

return function()

end