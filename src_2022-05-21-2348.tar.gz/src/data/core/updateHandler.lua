--[[
    This file is part of the NosGa Engine.
	
	NosGa Engine Copyright (c) 2019-2020 NosPo Studio

    The NosGa Engine is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The NosGa Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the NosGa Engine.  If not, see <https://www.gnu.org/licenses/>.
]]

--GameEngine
local global = ...
local uh = {
	isUpdated = {},
	signalQueue = {},
	sUpdateQueue = {},
	ocgfUpdateQueue = {},
}

--===== local vars =====--
local narrowUpdateExpansion = global.conf.narrowUpdateExpansion
local tableInsert = table.insert
local calcSUpdate = global.conf.calcSUpdate

--===== local functions =====--
local function print(...)
	if global.conf.debug.geDebug then
		global.debug.log(...)
	end
end

local function isInsideArea(ra, go, expansion)
	local x, y = go:getPos()
	local sx, sy = go.ngeAttributes.sizeX, go.ngeAttributes.sizeY
	local fromX, toX, fromY, toY = ra:getFOV()
	local expansion = expansion or {0, 0, 0, 0}
	
	if x +sx > fromX -expansion[1] and x < toX +expansion[2] and y +sy > fromY -expansion[3] and y < toY +expansion[4] then
		return true
	end
	
	return false
end

local function calculateFrame(renderArea)
	local expansion = renderArea.narrowUpdateExpansion
	
	if narrowUpdateExpansion ~= false then
		renderArea.updateAnything = false

		for go in pairs(renderArea.gameObjects) do
			local l = go.ngeAttributes.layer
			
			if renderArea.layerBlacklist[l] ~= true and 
				isInsideArea(renderArea, go, narrowUpdateExpansion) and 
				renderArea.toUpdate[go] == nil or
				go.ngeAttributes.updateAlways
			then 
				renderArea.toUpdate[go] = true
			end
		end
	else
		renderArea.updateAnything = true
	end
end

local function updateFrame(renderArea, dt)
	local toUpdate = renderArea.toUpdate
	local isUpdated = uh.isUpdated

	if renderArea.updateAnything then
		toUpdate = {}
		for go in pairs(renderArea.gameObjects) do
			if not go.ngeAttributes.ignoreOCGFGameObject then
				toUpdate[go] = true
			end
		end
	end
	
	for go, c in pairs(toUpdate) do
		if type(go) == "number" then
			go = c
			global.fatal("Update handler has unexpectet toUpdate table.") --currently not relevant.
		end

		if not isUpdated[go] then
			for i, s in pairs(uh.signalQueue) do
				global.run(go[s.name], go, s.signal, s.name)
			end
			
			go:ngeUpdate(toUpdate, dt, renderArea)
			if calcSUpdate then
				tableInsert(uh.sUpdateQueue, {go, renderArea})
			end
			isUpdated[go] = true
			--toUpdate[go] = nil
		end
	end
	
	renderArea.toUpdate = {}
end

--===== global functions =====--
function uh.init()
	
end

function uh.update(dt)
	dt = dt or global.dt
	
	for ra in pairs(global.renderAreas) do
		if not ra.silent then
			calculateFrame(ra)
			updateFrame(ra, dt)
		end
	end
	
	uh.isUpdated = {}
	uh.signalQueue = {}
end

function uh.sUpdate(dt)
	dt = dt or global.dt
	
	for i, suq in pairs(uh.sUpdateQueue) do
		suq[1]:ngeSUpdate(suq[2].gameObjects, dt, suq[2])
	end
	uh.sUpdateQueue = {}
end

function uh.insertSignal(s, signalName)
	
	--[[
	local t = s
	
	if signalName ~= nil then
		t = {signalName}
		for i, c in pairs(s) do
			if i > 1 then
				t[i] = c
			end
		end
		
		--uh.signalQueue[#uh.signalQueue][1] = signalName
	end
	]]
	--print(signalName)
	tableInsert(uh.signalQueue, {name = signalName, signal = s})
	
	--global.log(global.currentFrame, signalName)
	--global.slog(uh.signalQueue)
	
end

--===== init =====--
if not calcSUpdate then
	uh.sUpdate = function() end
end

return uh