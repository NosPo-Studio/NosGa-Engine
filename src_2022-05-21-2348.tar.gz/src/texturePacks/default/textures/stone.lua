local t = {

	textureFormat = "OCGLT",
	version = "v0.1",
	
	drawCalls = {
		{"b", 0x444444},
		{"f", 0x333333},
		{0, 0, 6, 3, "#"},
		--{1, 1, "######"},
		--{1, 2, "######"},
		--{1, 3, "######"},
	},
}


return t