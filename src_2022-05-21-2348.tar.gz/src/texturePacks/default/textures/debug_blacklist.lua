local t = {

	format = "OCGLT",
	version = "v1.0",
	
	drawCalls = {
		{"b", 0x333333},
		{"f", 0xaaaaaa},
		
		
		{0, 0, "######"},
		{0, 1, "123456"},
		{0, 2, "######"},
	},
}


return t
